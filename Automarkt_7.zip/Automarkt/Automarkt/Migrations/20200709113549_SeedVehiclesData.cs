﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Automarkt.Migrations
{
    public partial class SeedVehiclesData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Vehicle",
                columns: new[] { "Id", "Approved", "BuyerFullname", "BuyerPhone", "ChassisNumber", "Colour", "Description", "EmployeeId", "EnginePower", "Fuel", "Make", "Price", "SaleDate", "Weight", "buyerAddres", "cc", "pic" },
                values: new object[,]
                {
                    { "7", true, null, 0L, 225588L, "Black", "Small, quick, economical and very fun to drive.", "A2", 70, "Diesel", "Mercedes A170", 2000m, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 1100m, null, 1700, "/images/mece170.jpg" },
                    { "4", true, null, 0L, 333444L, "White", "Large and very luxurious car with sports car performance.", "A2", 220, "Diesel", "Mercedes S420", 19000m, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 3000m, null, 4200, "/images/s420.jpg" },
                    { "5", true, null, 0L, 775588L, "Dark blue", "Large low level luxury car with quiet and economical engine.", "A2", 90, "Diesel", "Audi A6", 5000m, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 1600m, null, 2000, "/images/a6.jpg" },
                    { "6", true, null, 0L, 666666L, "Light green", "Purebred japanese kamikazee machines. Feel the power of 72hp between your legs.", "A2", 53, "Petrol", "Kawasaki Ninja", 1500m, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 186m, null, 650, "/images/kawasakiNinja.jpg" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Vehicle",
                keyColumn: "Id",
                keyValue: "4");

            migrationBuilder.DeleteData(
                table: "Vehicle",
                keyColumn: "Id",
                keyValue: "5");

            migrationBuilder.DeleteData(
                table: "Vehicle",
                keyColumn: "Id",
                keyValue: "6");

            migrationBuilder.DeleteData(
                table: "Vehicle",
                keyColumn: "Id",
                keyValue: "7");
        }
    }
}
