﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Automarkt.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

namespace Automarkt.Models
{
    public class AutomarktContext : IdentityDbContext
    {
        private DbContext context;

        public AutomarktContext (DbContextOptions<AutomarktContext> options)
            : base(options)
        {
        }

        public DbSet<Automarkt.Models.Employee> Employee { get; set; }

        public DbSet<Automarkt.Models.Owner> Owner { get; set; }

        public DbSet<Automarkt.Models.Vehicle> Vehicle { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<Owner>().HasData(
            new Owner
             {
                 Id = "5",
                 Name = "Richie",
                 LastName = "Rich",
                 Phone = "035964862",
                 Email = "RichieR@RRmail.com"
             }
         );
            //var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));
            //var UserManager = new UserManager<>(new UserStore<IdentityUser>(context));
            //var user = new IdentityUser
            //{
            //    UserName = "admin@admin.net",
            //    Email = "admin@admin.net",
            //    Password = "password"
            //};

            //UserManager.Create(user);
            //UserManager.AddToRole(user.Id, "Admin");

            //var store = new UserStore<IdentityUser>(context);
            //var manager = new UserManager<IdentityUser>(store);
            //var user = new IdentityUser { UserName = "founder" };

            //manager.Create(user, "ChangeItAsap!");
            //context.Users.Add(user);
            //manager.AddToRole(user.Id, "AppAdmin");


            builder.Entity<Vehicle>().HasData(
            new Vehicle
            {
                Id = "7",
                Make = "Mercedes A170",
                cc = 1700,
                Fuel = "Diesel",
                EnginePower = 70,
                Colour = "Black",
                Price = 2000,
                Weight = 1100,
                Approved = true,
                Description = "Small, quick, economical and very fun to drive.",
                ChassisNumber = 225588,
                EmployeeId = "A2",
                pic = "/images/mece170.jpg"
            }
        );
            builder.Entity<Vehicle>().HasData(
          new Vehicle
          {
              Id = "4",
              Make = "Mercedes S420",
              cc = 4200,
              Fuel = "Diesel",
              EnginePower = 220,
              Colour = "White",
              Price = 19000,
              Weight = 3000,
              Approved = true,
              Description = "Large and very luxurious car with sports car performance.",
              ChassisNumber = 333444,
              EmployeeId = "A2",
              pic = "/images/s420.jpg"
          }
      );
            builder.Entity<Vehicle>().HasData(
          new Vehicle
          {
              Id = "5",
              Make = "Audi A6",
              cc = 2000,
              Fuel = "Diesel",
              EnginePower = 90,
              Colour = "Dark blue",
              Price = 5000,
              Weight = 1600,
              Approved = true,
              Description = "Large low level luxury car with quiet and economical engine.",
              ChassisNumber = 775588,
              EmployeeId = "A2",
              pic = "/images/a6.jpg"
          }
      );
            builder.Entity<Vehicle>().HasData(
          new Vehicle
          {
              Id = "6",
              Make = "Kawasaki Ninja",
              cc = 650,
              Fuel = "Petrol",
              EnginePower = 53,
              Colour = "Light green",
              Price = 1500,
              Weight = 186,
              Approved = true,
              Description = "Purebred japanese kamikazee machines. Feel the power of 72hp between your legs.",
              ChassisNumber = 666666,
              EmployeeId = "A2",
              pic = "/images/kawasakiNinja.jpg"
          }
      );
        }

    }
}
