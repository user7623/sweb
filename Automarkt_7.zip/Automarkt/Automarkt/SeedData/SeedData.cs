﻿using System;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Automarkt.Models;

namespace Automarkt
{
    public class SeedData
    {
        public static async void Initialize(IServiceProvider serviceProvider)
        {
            using (var scope = serviceProvider.CreateScope())
            {
                var context = scope.ServiceProvider.GetRequiredService<AutomarktContext>();
                string[] roles = new string[] { "Admin", "Employee" };
                foreach (string role in roles)
                {
                    var roleStore = new RoleStore<IdentityRole>(context);
                    if (!context.Roles.Any(r => r.Name == role))
                    {
                        var resultceo = await roleStore.CreateAsync(new IdentityRole(role)
                        {
                            NormalizedName = role.ToUpper()
                        });
                        if (resultceo.Succeeded)
                        {
                            System.Diagnostics.Debug.WriteLine("Succsess");
                        }
                        else
                        {
                            foreach (var error in resultceo.Errors)
                            {
                                System.Diagnostics.Debug.WriteLine(error.Description);
                            }
                        }
                    }
                }
                var Pownerce = new Owner
                {
                    Id = "5",
                    Name = "Richie",
                    LastName = "Rich",
                    Phone = "035964862",
                    Email = "RichieR@RRmail.com"
                };


                //if (!context.Users.Any(u => u.UserName == Pownerce.Name))
                //{
                //    var password = new PasswordHasher<Owner>();
                //    var hashed = password.HashPassword(Pownerce, "password");


                //    var userStore = new UserStore<Owner>(context);
                //    var result = await userStore.CreateAsync(Pownerce);

                //    UserManager<Owner> _userManager = scope.ServiceProvider.GetRequiredService<UserManager<Owner>>();
                //    Owner userce = await _userManager.FindByEmailAsync(Pownerce.Email);
                //    var resultce = await _userManager.AddToRoleAsync(userce, roles[0]);
                //}
                await context.SaveChangesAsync();

            }
        }
    }
}