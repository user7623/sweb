﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Automarkt.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace Automarkt.Models
{
    public class AutomarktContext : IdentityDbContext
    {
        public AutomarktContext (DbContextOptions<AutomarktContext> options)
            : base(options)
        {
        }

        public DbSet<Automarkt.Models.Employee> Employee { get; set; }

        public DbSet<Automarkt.Models.Owner> Owner { get; set; }

        public DbSet<Automarkt.Models.Vehicle> Vehicle { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }

    }
}
