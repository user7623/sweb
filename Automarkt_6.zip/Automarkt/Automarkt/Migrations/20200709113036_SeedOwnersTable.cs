﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Automarkt.Migrations
{
    public partial class SeedOwnersTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Owner",
                columns: new[] { "Id", "Email", "LastName", "Name", "Phone" },
                values: new object[] { "5", "RichieR@RRmail.com", "Rich", "Richie", "035964862" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Owner",
                keyColumn: "Id",
                keyValue: "5");
        }
    }
}
