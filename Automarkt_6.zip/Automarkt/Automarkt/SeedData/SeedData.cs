﻿//using System;
//using System.Linq;
//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.AspNetCore.Identity;
//using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
//using Automarkt.Models;

//namespace Automarkt
//{
//    public class SeedData
//    {
//        public static async void Initialize(IServiceProvider serviceProvider)
//        {
//            using (var scope = serviceProvider.CreateScope())
//            {
//                var context = scope.ServiceProvider.GetRequiredService<AutomarktContext>();
//                string[] roles = new string[] { "Admin", "Employee" };
//                foreach (string role in roles)
//                {
//                    var roleStore = new RoleStore<IdentityRole>(context);
//                    if (!context.Roles.Any(r => r.Name == role))
//                    {
//                        var resultceo = await roleStore.CreateAsync(new IdentityRole(role)
//                        {
//                            NormalizedName = role.ToUpper()
//                        });
//                        if (resultceo.Succeeded)
//                        {
//                            System.Diagnostics.Debug.WriteLine("Succsess");
//                        }
//                        else
//                        {
//                            foreach (var error in resultceo.Errors)
//                            {
//                                System.Diagnostics.Debug.WriteLine(error.Description);
//                            }
//                        }
//                    }
//                }

//                var vehicle01 = new Vehicle
//                {
//                    Id = "7",
//                    Make = "Mercedes A170",
//                    cc = 1700,
//                    Fuel = "Diesel",
//                    EnginePower = 70,
//                    Colour = "Black",
//                    Price = 2000,
//                    Weight = 1100,
//                    Approved = true,
//                    Description = "Small, quick, economical and very fun to drive.",
//                    ChassisNumber = 225588,
//                    EmployeeId = "A2",
//                    pic = "/images/mece170.jpg"
//                };
//                var vehicle02 = new Vehicle
//                {
//                    Id = "4",
//                    Make = "Mercedes S420",
//                    cc = 4200,
//                    Fuel = "Diesel",
//                    EnginePower = 220,
//                    Colour = "White",
//                    Price = 19000,
//                    Weight = 3000,
//                    Approved = true,
//                    Description = "Large and very luxurious car with sports car performance.",
//                    ChassisNumber = 333444,
//                    EmployeeId = "A2",
//                    pic = "/images/s420.jpg"
//                };
//                var vehicle03 = new Vehicle
//                {
//                    Id = "5",
//                    Make = "Audi A6",
//                    cc = 2000,
//                    Fuel = "Diesel",
//                    EnginePower = 90,
//                    Colour = "Dark blue",
//                    Price = 5000,
//                    Weight = 1600,
//                    Approved = true,
//                    Description = "Large low level luxury car with quiet and economical engine.",
//                    ChassisNumber = 775588,
//                    EmployeeId = "A2",
//                    pic = "/images/a6.jpg"
//                };
//                var vehicle04 = new Vehicle
//                {
//                    Id = "6",
//                    Make = "Kawasaki Ninja",
//                    cc = 650,
//                    Fuel = "Petrol",
//                    EnginePower = 53,
//                    Colour = "Light green",
//                    Price = 1500,
//                    Weight = 186,
//                    Approved = true,
//                    Description = "Purebred japanese kamikazee machines. Feel the power of 72hp between your legs.",
//                    ChassisNumber = 666666,
//                    EmployeeId = "A2",
//                    pic = "/images/kawasakiNinja.jpg"
//                };
//                var owner = new Owner
//                {
//                    Id = "5",
//                    Name = "Richie",
//                    LastName = "Rich",
//                    Phone = "035964862",
//                    Email = "RichieR@RRmail.com"
//                };
//                if (!context.Users.Any(u => u.Email == owner.Email))
//                {
//                    var userStore = new UserStore<>(context);
//                    var result = await userStore.CreateAsync(owner);


//                    UserManager<Owner> _userManager = scope.ServiceProvider.GetRequiredService<UserManager<Owner>>();
//                    Owner mUser = await _userManager.FindByEmailAsync(owner.Email);
//                    var fresult = await _userManager.AddToRoleAsync(mUser, roles[0]);
//                }
//                await context.SaveChangesAsync();

//            }
//        }
//    }
//}